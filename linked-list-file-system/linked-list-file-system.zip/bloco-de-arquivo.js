export class Bloco {
    constructor(dado, ponteiro) {
        this.dado = dado;
        this.ponteiro = ponteiro;      
    }
}